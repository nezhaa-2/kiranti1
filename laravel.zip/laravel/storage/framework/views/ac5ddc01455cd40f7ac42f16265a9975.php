<?php $__env->startSection('judul', 'Stok masuk'); ?>
<?php $__env->startSection('isi'); ?>
<h1>Catat stok masuk</h1>
<form class="isian" method="POST" action="<?php echo e(route('stok-masuk.store')); ?>">
    <?php echo csrf_field(); ?>
    <label for="benih_id">Benih</label>
    <select id="benih_id" name="benih_id">
        <option value="">Pilih benih</option>
        <?php $__currentLoopData = $benih; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($b->id); ?>" <?php if(old('benih_id', $dipilih) == $b->id): echo 'selected'; endif; ?>><?php echo e($b->nama); ?> (stok <?php echo e($b->stok); ?> kg)</option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <?php $__errorArgs = ['benih_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="galat"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <label for="jumlah">Jumlah masuk (kg)</label>
    <input id="jumlah" type="number" name="jumlah" min="1" value="<?php echo e(old('jumlah')); ?>">
    <?php $__errorArgs = ['jumlah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="galat"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <label for="harga_beli">Harga beli per kg (Rp, opsional)</label>
    <input id="harga_beli" type="number" name="harga_beli" min="0" step="any" value="<?php echo e(old('harga_beli')); ?>">

    <label for="tanggal">Tanggal</label>
    <input id="tanggal" type="date" name="tanggal" value="<?php echo e(old('tanggal', now()->toDateString())); ?>">

    <label for="keterangan">Keterangan (opsional)</label>
    <input id="keterangan" type="text" name="keterangan" value="<?php echo e(old('keterangan')); ?>">

    <div class="aksi" style="margin-top:20px"><button class="btn">Simpan stok masuk</button></div>
</form>

<?php if($riwayat->isNotEmpty()): ?>
    <h2>Stok masuk terakhir</h2>
    <table>
        <tr><th>Tanggal</th><th>Benih</th><th class="angka">Jumlah (kg)</th><th>Keterangan</th></tr>
        <?php $__currentLoopData = $riwayat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($r->tanggal->format('d/m/Y')); ?></td>
                <td><?php echo e($r->benih->nama); ?></td>
                <td class="angka"><?php echo e(number_format($r->jumlah, 0, ',', '.')); ?></td>
                <td><?php echo e($r->keterangan ?: '-'); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\tandur garit\laravel\resources\views/stok_masuk/create.blade.php ENDPATH**/ ?>