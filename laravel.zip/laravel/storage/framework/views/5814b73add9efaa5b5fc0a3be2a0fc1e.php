<?php $__env->startSection('judul', 'Penjualan'); ?>
<?php $__env->startSection('isi'); ?>
<h1>Penjualan</h1>
<div class="aksi"><a class="btn" href="<?php echo e(route('penjualan.create')); ?>">Catat penjualan</a></div>
<table>
    <tr><th>Tanggal</th><th>Benih</th><th>Pembeli</th><th class="angka">Jumlah (kg)</th><th class="angka">Total</th><th></th></tr>
    <?php $__empty_1 = true; $__currentLoopData = $daftar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($p->tanggal->format('d/m/Y')); ?></td>
            <td><?php echo e($p->benih->nama); ?></td>
            <td><?php echo e($p->pembeli ?: '-'); ?></td>
            <td class="angka"><?php echo e(number_format($p->jumlah, 0, ',', '.')); ?></td>
            <td class="angka">Rp <?php echo e(number_format($p->total, 0, ',', '.')); ?></td>
            <td class="angka">
                <form method="POST" action="<?php echo e(route('penjualan.destroy', $p)); ?>" onsubmit="return confirm('Batalkan penjualan ini? Stok akan dikembalikan.')">
                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                    <button class="btn kecil bahaya">Batalkan</button>
                </form>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td colspan="6">Belum ada penjualan tercatat.</td></tr>
    <?php endif; ?>
</table>
<div style="margin-top:16px"><?php echo e($daftar->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\tandur garit\laravel\resources\views/penjualan/index.blade.php ENDPATH**/ ?>