<?php $__env->startSection('judul', 'Ringkasan'); ?>
<?php $__env->startSection('isi'); ?>
<h1>Ringkasan</h1>

<div class="ringkas">
    <div class="perkiraan">
        <div class="ket">Perkiraan pendapatan bulan depan</div>
        <div class="nilai">Rp <?php echo e(number_format($perkiraanBulanDepan, 0, ',', '.')); ?></div>
        <div class="ket">Rata-rata 3 bulan terakhir</div>
    </div>
    <div>
        <div class="ket">Potensi pendapatan dari stok</div>
        <div class="nilai">Rp <?php echo e(number_format($potensiPendapatan, 0, ',', '.')); ?></div>
        <div class="ket"><?php echo e(number_format($totalStok, 0, ',', '.')); ?> kg tersedia</div>
    </div>
    <div>
        <div class="ket">Pendapatan bulan ini</div>
        <div class="nilai">Rp <?php echo e(number_format($pendapatanBulanIni, 0, ',', '.')); ?></div>
        <div class="ket">Total semua: Rp <?php echo e(number_format($totalPendapatan, 0, ',', '.')); ?></div>
    </div>
</div>

<?php if($stokMenipis->isNotEmpty()): ?>
    <h2>Stok hampir habis</h2>
    <table>
        <?php $__currentLoopData = $stokMenipis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($b->nama); ?></td>
                <td class="angka menipis"><?php echo e($b->stok); ?> kg (minimum <?php echo e($b->stok_minimum); ?>)</td>
                <td class="angka"><a class="btn kecil sekunder" href="<?php echo e(route('stok-masuk.create', ['benih_id' => $b->id])); ?>">Tambah stok</a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php endif; ?>

<div class="dua">
    <div>
        <h2>Penjualan 12 bulan terakhir</h2>
        <div class="kotak"><canvas id="grafikPenjualan" height="140"></canvas></div>
    </div>
    <div>
        <h2>Benih paling banyak dipilih</h2>
        <div class="kotak"><canvas id="grafikTerlaris" height="220"></canvas></div>
    </div>
</div>

<h2>Peringkat benih</h2>
<table>
    <tr><th>Benih</th><th class="angka">Terjual (kg)</th><th class="angka">Transaksi</th><th class="angka">Pendapatan</th></tr>
    <?php $__empty_1 = true; $__currentLoopData = $terlaris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($t->benih->nama); ?></td>
            <td class="angka"><?php echo e(number_format($t->total_terjual, 0, ',', '.')); ?></td>
            <td class="angka"><?php echo e($t->jumlah_transaksi); ?></td>
            <td class="angka">Rp <?php echo e(number_format($t->total_pendapatan, 0, ',', '.')); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td colspan="4">Belum ada penjualan. <a href="<?php echo e(route('penjualan.create')); ?>">Catat penjualan pertama</a>.</td></tr>
    <?php endif; ?>
</table>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<script>
    const rupiah = v => 'Rp ' + Number(v).toLocaleString('id-ID');

    new Chart(document.getElementById('grafikPenjualan'), {
        type: 'line',
        data: {
            labels: <?php echo json_encode($labels, 15, 512) ?>,
            datasets: [{ label: 'Penjualan', data: <?php echo json_encode($data, 15, 512) ?>, borderColor: '#2E5E3E', backgroundColor: 'rgba(46,94,62,.12)', fill: true, tension: .3 }]
        },
        options: {
            plugins: { legend: { display: false }, tooltip: { callbacks: { label: c => rupiah(c.parsed.y) } } },
            scales: { y: { beginAtZero: true, ticks: { callback: v => (v / 1000000) + ' jt' } } }
        }
    });

    new Chart(document.getElementById('grafikTerlaris'), {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($terlaris->map(fn ($t) => $t->benih->nama), 15, 512) ?>,
            datasets: [{ label: 'Terjual (kg)', data: <?php echo json_encode($terlaris->pluck('total_terjual'), 15, 512) ?>, backgroundColor: '#C9962B' }]
        },
        options: { indexAxis: 'y', plugins: { legend: { display: false } } }
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\tandur garit\laravel\resources\views/dashboard.blade.php ENDPATH**/ ?>