<?php $__env->startSection('judul', $benih->exists ? 'Ubah benih' : 'Tambah benih'); ?>
<?php $__env->startSection('isi'); ?>
<h1><?php echo e($benih->exists ? 'Ubah benih' : 'Tambah benih'); ?></h1>
<form class="isian" method="POST" action="<?php echo e($benih->exists ? route('benih.update', $benih) : route('benih.store')); ?>">
    <?php echo csrf_field(); ?>
    <?php if($benih->exists): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

    <?php $__currentLoopData = [
        ['nama', 'Nama benih', 'text'],
        ['varietas', 'Varietas', 'text'],
        ['harga_jual', 'Harga jual per kg (Rp)', 'number'],
        ['stok', 'Stok (kg)', 'number'],
        ['stok_minimum', 'Batas stok menipis (kg)', 'number'],
    ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$nama, $label, $tipe]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <label for="<?php echo e($nama); ?>"><?php echo e($label); ?></label>
        <input id="<?php echo e($nama); ?>" type="<?php echo e($tipe); ?>" name="<?php echo e($nama); ?>" value="<?php echo e(old($nama, $benih->$nama)); ?>" <?php if($tipe === 'number'): ?> min="0" step="any" <?php endif; ?>>
        <?php $__errorArgs = [$nama];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="galat"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <div class="aksi" style="margin-top:20px">
        <button class="btn">Simpan</button>
        <a class="btn sekunder" href="<?php echo e(route('benih.index')); ?>">Batal</a>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\tandur garit\laravel\resources\views/benih/form.blade.php ENDPATH**/ ?>