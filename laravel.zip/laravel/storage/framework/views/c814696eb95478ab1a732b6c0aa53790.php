<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('judul', 'Stok Benih Padi'); ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Public+Sans:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        :root { --padi:#2E5E3E; --padi-tua:#1E3F2A; --gabah:#C9962B; --latar:#F5F6F2; --garis:#DDE1D8; --teks:#1F2A22; --pudar:#667066; --bahaya:#B3402A; }
        * { box-sizing: border-box; }
        body { margin:0; font-family:'Public Sans',system-ui,sans-serif; background:var(--latar); color:var(--teks); line-height:1.55; }
        nav { background:var(--padi-tua); padding:0 24px; display:flex; gap:4px; align-items:center; flex-wrap:wrap; }
        nav .merek { color:#fff; font-weight:700; margin-right:24px; padding:16px 0; }
        nav a { color:#C9D6CB; text-decoration:none; padding:16px 12px; }
        nav a:hover, nav a.aktif { color:#fff; box-shadow:inset 0 -3px var(--gabah); }
        main { max-width:1080px; margin:0 auto; padding:28px 24px 64px; }
        h1 { font-size:1.6rem; margin:0 0 20px; }
        h2 { font-size:1.1rem; margin:32px 0 12px; }
        table { width:100%; border-collapse:collapse; background:#fff; border:1px solid var(--garis); }
        th, td { text-align:left; padding:10px 12px; border-bottom:1px solid var(--garis); }
        th { font-weight:500; color:var(--pudar); background:#FAFBF8; }
        td.angka, th.angka { text-align:right; font-variant-numeric:tabular-nums; }
        .btn { display:inline-block; background:var(--padi); color:#fff; border:0; padding:9px 16px; border-radius:4px; font:inherit; cursor:pointer; text-decoration:none; }
        .btn:hover { background:var(--padi-tua); }
        .btn.sekunder { background:#fff; color:var(--padi); border:1px solid var(--padi); }
        .btn.bahaya { background:#fff; color:var(--bahaya); border:1px solid var(--bahaya); }
        .btn.kecil { padding:4px 10px; font-size:.875rem; }
        .aksi { display:flex; gap:8px; margin-bottom:16px; }
        form.isian label { display:block; margin:14px 0 4px; font-weight:500; }
        form.isian input, form.isian select { width:100%; max-width:420px; padding:9px 10px; border:1px solid #BFC6BA; border-radius:4px; font:inherit; background:#fff; }
        .galat { color:var(--bahaya); font-size:.875rem; margin-top:4px; }
        .ok { background:#E6F0E8; border-left:4px solid var(--padi); padding:10px 14px; margin-bottom:20px; }
        .menipis { color:var(--bahaya); font-weight:500; }
        .ringkas { display:grid; grid-template-columns:repeat(auto-fit,minmax(210px,1fr)); gap:0; background:#fff; border:1px solid var(--garis); }
        .ringkas > div { padding:16px 18px; border-right:1px solid var(--garis); }
        .ringkas > div:last-child { border-right:0; }
        .ringkas .nilai { font-size:1.35rem; font-weight:700; }
        .ringkas .ket { color:var(--pudar); font-size:.875rem; }
        .perkiraan .nilai { color:var(--padi); }
        .dua { display:grid; grid-template-columns:2fr 1fr; gap:24px; }
        .kotak { background:#fff; border:1px solid var(--garis); padding:16px; }
        @media (max-width:760px){ .dua { grid-template-columns:1fr; } .ringkas > div { border-right:0; border-bottom:1px solid var(--garis); } }
    </style>
</head>
<body>
<nav>
    <span class="merek">Stok Benih Padi</span>
    <?php if(auth()->guard()->check()): ?>
        <a href="<?php echo e(route('dashboard')); ?>" class="<?php echo e(request()->routeIs('dashboard') ? 'aktif' : ''); ?>">Ringkasan</a>
        <a href="<?php echo e(route('benih.index')); ?>" class="<?php echo e(request()->routeIs('benih.*') ? 'aktif' : ''); ?>">Stok benih</a>
        <a href="<?php echo e(route('penjualan.index')); ?>" class="<?php echo e(request()->routeIs('penjualan.*') ? 'aktif' : ''); ?>">Penjualan</a>
        <a href="<?php echo e(route('stok-masuk.create')); ?>" class="<?php echo e(request()->routeIs('stok-masuk.*') ? 'aktif' : ''); ?>">Stok masuk</a>
        <form method="POST" action="<?php echo e(route('logout')); ?>" style="margin-left:auto">
            <?php echo csrf_field(); ?>
            <button style="background:none;border:0;color:#C9D6CB;font:inherit;cursor:pointer;padding:16px 12px">Keluar (<?php echo e(auth()->user()->name); ?>)</button>
        </form>
    <?php endif; ?>
</nav>
<main>
    <?php if(session('ok')): ?> <div class="ok"><?php echo e(session('ok')); ?></div> <?php endif; ?>
    <?php echo $__env->yieldContent('isi'); ?>
</main>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel\tandur garit\laravel\resources\views/layouts/app.blade.php ENDPATH**/ ?>