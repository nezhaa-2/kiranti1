<?php $__env->startSection('judul', 'Catat penjualan'); ?>
<?php $__env->startSection('isi'); ?>
<h1>Catat penjualan</h1>
<form class="isian" method="POST" action="<?php echo e(route('penjualan.store')); ?>">
    <?php echo csrf_field(); ?>
    <label for="benih_id">Benih</label>
    <select id="benih_id" name="benih_id">
        <option value="">Pilih benih</option>
        <?php $__currentLoopData = $benih; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($b->id); ?>" <?php if(old('benih_id') == $b->id): echo 'selected'; endif; ?>><?php echo e($b->nama); ?> - sisa <?php echo e($b->stok); ?> kg - Rp <?php echo e(number_format($b->harga_jual, 0, ',', '.')); ?>/kg</option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <?php $__errorArgs = ['benih_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="galat"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <label for="jumlah">Jumlah (kg)</label>
    <input id="jumlah" type="number" name="jumlah" min="1" value="<?php echo e(old('jumlah')); ?>">
    <?php $__errorArgs = ['jumlah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="galat"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <label for="tanggal">Tanggal</label>
    <input id="tanggal" type="date" name="tanggal" value="<?php echo e(old('tanggal', now()->toDateString())); ?>">
    <?php $__errorArgs = ['tanggal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="galat"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <label for="pembeli">Pembeli (opsional)</label>
    <input id="pembeli" type="text" name="pembeli" value="<?php echo e(old('pembeli')); ?>">

    <div class="aksi" style="margin-top:20px">
        <button class="btn">Simpan penjualan</button>
        <a class="btn sekunder" href="<?php echo e(route('penjualan.index')); ?>">Batal</a>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\tandur garit\laravel\resources\views/penjualan/create.blade.php ENDPATH**/ ?>