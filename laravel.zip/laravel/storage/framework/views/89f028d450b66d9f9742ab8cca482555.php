<?php $__env->startSection('judul', 'Stok benih'); ?>
<?php $__env->startSection('isi'); ?>
<h1>Stok benih</h1>
<div class="aksi">
    <a class="btn" href="<?php echo e(route('benih.create')); ?>">Tambah benih</a>
    <a class="btn sekunder" href="<?php echo e(route('stok-masuk.create')); ?>">Catat stok masuk</a>
</div>
<table>
    <tr><th>Nama</th><th>Varietas</th><th class="angka">Harga/kg</th><th class="angka">Stok (kg)</th><th class="angka">Nilai stok</th><th></th></tr>
    <?php $__empty_1 = true; $__currentLoopData = $daftar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($b->nama); ?></td>
            <td><?php echo e($b->varietas ?: '-'); ?></td>
            <td class="angka">Rp <?php echo e(number_format($b->harga_jual, 0, ',', '.')); ?></td>
            <td class="angka <?php echo e($b->menipis ? 'menipis' : ''); ?>"><?php echo e(number_format($b->stok, 0, ',', '.')); ?><?php echo e($b->menipis ? ' (menipis)' : ''); ?></td>
            <td class="angka">Rp <?php echo e(number_format($b->stok * $b->harga_jual, 0, ',', '.')); ?></td>
            <td class="angka">
                <a class="btn kecil sekunder" href="<?php echo e(route('benih.edit', $b)); ?>">Ubah</a>
                <form method="POST" action="<?php echo e(route('benih.destroy', $b)); ?>" style="display:inline" onsubmit="return confirm('Hapus <?php echo e($b->nama); ?> beserta riwayat penjualannya?')">
                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                    <button class="btn kecil bahaya">Hapus</button>
                </form>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td colspan="6">Belum ada benih. Tambahkan benih pertama untuk mulai mencatat stok.</td></tr>
    <?php endif; ?>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\tandur garit\laravel\resources\views/benih/index.blade.php ENDPATH**/ ?>