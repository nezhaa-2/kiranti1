<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class StokMasuk extends Model
{
    protected $table = 'stok_masuk';
    protected $fillable = ['benih_id', 'jumlah', 'harga_beli', 'tanggal', 'keterangan'];
    protected $casts = ['tanggal' => 'date'];

    public function benih()
    {
        return $this->belongsTo(Benih::class);
    }
}
