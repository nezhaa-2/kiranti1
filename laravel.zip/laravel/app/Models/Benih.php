<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Benih extends Model
{
    protected $table = 'benih';
    protected $fillable = ['nama', 'varietas', 'harga_jual', 'stok', 'stok_minimum'];

    public function penjualan()
    {
        return $this->hasMany(Penjualan::class);
    }

    public function stokMasuk()
    {
        return $this->hasMany(StokMasuk::class);
    }

    public function getMenipisAttribute(): bool
    {
        return $this->stok <= $this->stok_minimum;
    }
}
