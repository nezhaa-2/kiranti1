<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Penjualan extends Model
{
    protected $table = 'penjualan';
    protected $fillable = ['benih_id', 'jumlah', 'harga_satuan', 'total', 'tanggal', 'pembeli'];
    protected $casts = ['tanggal' => 'date'];

    public function benih()
    {
        return $this->belongsTo(Benih::class);
    }
}
