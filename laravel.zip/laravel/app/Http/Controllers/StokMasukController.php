<?php

namespace App\Http\Controllers;

use App\Models\Benih;
use App\Models\StokMasuk;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class StokMasukController extends Controller
{
    public function create(Request $request)
    {
        return view('stok_masuk.create', [
            'benih' => Benih::orderBy('nama')->get(),
            'dipilih' => $request->query('benih_id'),
            'riwayat' => StokMasuk::with('benih')->latest('tanggal')->latest('id')->take(10)->get(),
        ]);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'benih_id' => 'required|exists:benih,id',
            'jumlah' => 'required|integer|min:1',
            'harga_beli' => 'nullable|numeric|min:0',
            'tanggal' => 'required|date',
            'keterangan' => 'nullable|string|max:255',
        ]);

        DB::transaction(function () use ($data) {
            StokMasuk::create($data);
            Benih::whereKey($data['benih_id'])->increment('stok', $data['jumlah']);
        });

        return redirect()->route('benih.index')->with('ok', 'Stok masuk dicatat.');
    }
}
