<?php

namespace App\Http\Controllers;

use App\Models\Benih;
use App\Models\Penjualan;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function index()
    {
        $benih = Benih::orderBy('nama')->get();

        // Potensi pendapatan bila seluruh stok yang ada terjual
        $potensiPendapatan = $benih->sum(fn ($b) => $b->stok * $b->harga_jual);
        $totalStok = $benih->sum('stok');
        $stokMenipis = $benih->filter(fn ($b) => $b->menipis);

        // Penjualan 12 bulan terakhir (dikelompokkan di PHP agar jalan di MySQL/SQLite/PostgreSQL)
        $awal = now()->subMonths(11)->startOfMonth();
        $perBulan = Penjualan::where('tanggal', '>=', $awal)->get()
            ->groupBy(fn ($p) => $p->tanggal->format('Y-m'))
            ->map(fn ($g) => (float) $g->sum('total'));

        $labels = [];
        $data = [];
        for ($i = 0; $i < 12; $i++) {
            $bulan = $awal->copy()->addMonths($i);
            $labels[] = $bulan->format('M Y');
            $data[] = $perBulan[$bulan->format('Y-m')] ?? 0;
        }

        // Perkiraan pendapatan bulan depan: rata-rata 3 bulan terakhir
        $perkiraanBulanDepan = round(array_sum(array_slice($data, -3)) / 3);

        // Produk paling banyak dipilih
        $terlaris = Penjualan::select(
                'benih_id',
                DB::raw('SUM(jumlah) as total_terjual'),
                DB::raw('SUM(total) as total_pendapatan'),
                DB::raw('COUNT(*) as jumlah_transaksi')
            )
            ->groupBy('benih_id')
            ->with('benih')
            ->orderByDesc('total_terjual')
            ->take(5)
            ->get();

        return view('dashboard', [
            'potensiPendapatan' => $potensiPendapatan,
            'totalStok' => $totalStok,
            'stokMenipis' => $stokMenipis,
            'pendapatanBulanIni' => end($data),
            'totalPendapatan' => Penjualan::sum('total'),
            'perkiraanBulanDepan' => $perkiraanBulanDepan,
            'labels' => $labels,
            'data' => $data,
            'terlaris' => $terlaris,
        ]);
    }
}
