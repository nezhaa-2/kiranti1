<?php

namespace App\Http\Controllers;

use App\Models\Benih;
use App\Models\Penjualan;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class PenjualanController extends Controller
{
    public function index()
    {
        return view('penjualan.index', [
            'daftar' => Penjualan::with('benih')->latest('tanggal')->latest('id')->paginate(20),
        ]);
    }

    public function create()
    {
        return view('penjualan.create', ['benih' => Benih::where('stok', '>', 0)->orderBy('nama')->get()]);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'benih_id' => 'required|exists:benih,id',
            'jumlah' => 'required|integer|min:1',
            'tanggal' => 'required|date',
            'pembeli' => 'nullable|string|max:255',
        ]);

        DB::transaction(function () use ($data) {
            $benih = Benih::lockForUpdate()->findOrFail($data['benih_id']);

            if ($benih->stok < $data['jumlah']) {
                throw ValidationException::withMessages([
                    'jumlah' => "Stok tidak cukup. Tersisa {$benih->stok} kg.",
                ]);
            }

            Penjualan::create($data + [
                'harga_satuan' => $benih->harga_jual,
                'total' => $benih->harga_jual * $data['jumlah'],
            ]);
            $benih->decrement('stok', $data['jumlah']);
        });

        return redirect()->route('penjualan.index')->with('ok', 'Penjualan dicatat dan stok dikurangi.');
    }

    public function destroy(Penjualan $penjualan)
    {
        DB::transaction(function () use ($penjualan) {
            Benih::whereKey($penjualan->benih_id)->increment('stok', $penjualan->jumlah);
            $penjualan->delete();
        });

        return redirect()->route('penjualan.index')->with('ok', 'Penjualan dibatalkan dan stok dikembalikan.');
    }
}
