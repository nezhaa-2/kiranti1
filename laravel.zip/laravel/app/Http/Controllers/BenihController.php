<?php

namespace App\Http\Controllers;

use App\Models\Benih;
use Illuminate\Http\Request;

class BenihController extends Controller
{
    private function aturan(): array
    {
        return [
            'nama' => 'required|string|max:255',
            'varietas' => 'nullable|string|max:255',
            'harga_jual' => 'required|numeric|min:0',
            'stok' => 'required|integer|min:0',
            'stok_minimum' => 'required|integer|min:0',
        ];
    }

    public function index()
    {
        return view('benih.index', ['daftar' => Benih::orderBy('nama')->get()]);
    }

    public function create()
    {
        return view('benih.form', ['benih' => new Benih(['stok' => 0, 'stok_minimum' => 20])]);
    }

    public function store(Request $request)
    {
        Benih::create($request->validate($this->aturan()));
        return redirect()->route('benih.index')->with('ok', 'Benih ditambahkan.');
    }

    public function edit(Benih $benih)
    {
        return view('benih.form', compact('benih'));
    }

    public function update(Request $request, Benih $benih)
    {
        $benih->update($request->validate($this->aturan()));
        return redirect()->route('benih.index')->with('ok', 'Benih diperbarui.');
    }

    public function destroy(Benih $benih)
    {
        $benih->delete();
        return redirect()->route('benih.index')->with('ok', 'Benih dihapus.');
    }
}
