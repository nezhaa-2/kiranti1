@extends('layouts.app')
@section('judul', 'Ringkasan')
@section('isi')
<h1>Ringkasan</h1>

<div class="ringkas">
    <div class="perkiraan">
        <div class="ket">Perkiraan pendapatan bulan depan</div>
        <div class="nilai">Rp {{ number_format($perkiraanBulanDepan, 0, ',', '.') }}</div>
        <div class="ket">Rata-rata 3 bulan terakhir</div>
    </div>
    <div>
        <div class="ket">Potensi pendapatan dari stok</div>
        <div class="nilai">Rp {{ number_format($potensiPendapatan, 0, ',', '.') }}</div>
        <div class="ket">{{ number_format($totalStok, 0, ',', '.') }} kg tersedia</div>
    </div>
    <div>
        <div class="ket">Pendapatan bulan ini</div>
        <div class="nilai">Rp {{ number_format($pendapatanBulanIni, 0, ',', '.') }}</div>
        <div class="ket">Total semua: Rp {{ number_format($totalPendapatan, 0, ',', '.') }}</div>
    </div>
</div>

@if($stokMenipis->isNotEmpty())
    <h2>Stok hampir habis</h2>
    <table>
        @foreach($stokMenipis as $b)
            <tr>
                <td>{{ $b->nama }}</td>
                <td class="angka menipis">{{ $b->stok }} kg (minimum {{ $b->stok_minimum }})</td>
                <td class="angka"><a class="btn kecil sekunder" href="{{ route('stok-masuk.create', ['benih_id' => $b->id]) }}">Tambah stok</a></td>
            </tr>
        @endforeach
    </table>
@endif

<div class="dua">
    <div>
        <h2>Penjualan 12 bulan terakhir</h2>
        <div class="kotak"><canvas id="grafikPenjualan" height="140"></canvas></div>
    </div>
    <div>
        <h2>Benih paling banyak dipilih</h2>
        <div class="kotak"><canvas id="grafikTerlaris" height="220"></canvas></div>
    </div>
</div>

<h2>Peringkat benih</h2>
<table>
    <tr><th>Benih</th><th class="angka">Terjual (kg)</th><th class="angka">Transaksi</th><th class="angka">Pendapatan</th></tr>
    @forelse($terlaris as $t)
        <tr>
            <td>{{ $t->benih->nama }}</td>
            <td class="angka">{{ number_format($t->total_terjual, 0, ',', '.') }}</td>
            <td class="angka">{{ $t->jumlah_transaksi }}</td>
            <td class="angka">Rp {{ number_format($t->total_pendapatan, 0, ',', '.') }}</td>
        </tr>
    @empty
        <tr><td colspan="4">Belum ada penjualan. <a href="{{ route('penjualan.create') }}">Catat penjualan pertama</a>.</td></tr>
    @endforelse
</table>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<script>
    const rupiah = v => 'Rp ' + Number(v).toLocaleString('id-ID');

    new Chart(document.getElementById('grafikPenjualan'), {
        type: 'line',
        data: {
            labels: @json($labels),
            datasets: [{ label: 'Penjualan', data: @json($data), borderColor: '#2E5E3E', backgroundColor: 'rgba(46,94,62,.12)', fill: true, tension: .3 }]
        },
        options: {
            plugins: { legend: { display: false }, tooltip: { callbacks: { label: c => rupiah(c.parsed.y) } } },
            scales: { y: { beginAtZero: true, ticks: { callback: v => (v / 1000000) + ' jt' } } }
        }
    });

    new Chart(document.getElementById('grafikTerlaris'), {
        type: 'bar',
        data: {
            labels: @json($terlaris->map(fn ($t) => $t->benih->nama)),
            datasets: [{ label: 'Terjual (kg)', data: @json($terlaris->pluck('total_terjual')), backgroundColor: '#C9962B' }]
        },
        options: { indexAxis: 'y', plugins: { legend: { display: false } } }
    });
</script>
@endsection
