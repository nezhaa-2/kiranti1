@extends('layouts.app')
@section('judul', $benih->exists ? 'Ubah benih' : 'Tambah benih')
@section('isi')
<h1>{{ $benih->exists ? 'Ubah benih' : 'Tambah benih' }}</h1>
<form class="isian" method="POST" action="{{ $benih->exists ? route('benih.update', $benih) : route('benih.store') }}">
    @csrf
    @if($benih->exists) @method('PUT') @endif

    @foreach([
        ['nama', 'Nama benih', 'text'],
        ['varietas', 'Varietas', 'text'],
        ['harga_jual', 'Harga jual per kg (Rp)', 'number'],
        ['stok', 'Stok (kg)', 'number'],
        ['stok_minimum', 'Batas stok menipis (kg)', 'number'],
    ] as [$nama, $label, $tipe])
        <label for="{{ $nama }}">{{ $label }}</label>
        <input id="{{ $nama }}" type="{{ $tipe }}" name="{{ $nama }}" value="{{ old($nama, $benih->$nama) }}" @if($tipe === 'number') min="0" step="any" @endif>
        @error($nama) <div class="galat">{{ $message }}</div> @enderror
    @endforeach

    <div class="aksi" style="margin-top:20px">
        <button class="btn">Simpan</button>
        <a class="btn sekunder" href="{{ route('benih.index') }}">Batal</a>
    </div>
</form>
@endsection
