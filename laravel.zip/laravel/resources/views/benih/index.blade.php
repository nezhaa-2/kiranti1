@extends('layouts.app')
@section('judul', 'Stok benih')
@section('isi')
<h1>Stok benih</h1>
<div class="aksi">
    <a class="btn" href="{{ route('benih.create') }}">Tambah benih</a>
    <a class="btn sekunder" href="{{ route('stok-masuk.create') }}">Catat stok masuk</a>
</div>
<table>
    <tr><th>Nama</th><th>Varietas</th><th class="angka">Harga/kg</th><th class="angka">Stok (kg)</th><th class="angka">Nilai stok</th><th></th></tr>
    @forelse($daftar as $b)
        <tr>
            <td>{{ $b->nama }}</td>
            <td>{{ $b->varietas ?: '-' }}</td>
            <td class="angka">Rp {{ number_format($b->harga_jual, 0, ',', '.') }}</td>
            <td class="angka {{ $b->menipis ? 'menipis' : '' }}">{{ number_format($b->stok, 0, ',', '.') }}{{ $b->menipis ? ' (menipis)' : '' }}</td>
            <td class="angka">Rp {{ number_format($b->stok * $b->harga_jual, 0, ',', '.') }}</td>
            <td class="angka">
                <a class="btn kecil sekunder" href="{{ route('benih.edit', $b) }}">Ubah</a>
                <form method="POST" action="{{ route('benih.destroy', $b) }}" style="display:inline" onsubmit="return confirm('Hapus {{ $b->nama }} beserta riwayat penjualannya?')">
                    @csrf @method('DELETE')
                    <button class="btn kecil bahaya">Hapus</button>
                </form>
            </td>
        </tr>
    @empty
        <tr><td colspan="6">Belum ada benih. Tambahkan benih pertama untuk mulai mencatat stok.</td></tr>
    @endforelse
</table>
@endsection
