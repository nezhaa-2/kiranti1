@extends('layouts.app')
@section('judul', 'Penjualan')
@section('isi')
<h1>Penjualan</h1>
<div class="aksi"><a class="btn" href="{{ route('penjualan.create') }}">Catat penjualan</a></div>
<table>
    <tr><th>Tanggal</th><th>Benih</th><th>Pembeli</th><th class="angka">Jumlah (kg)</th><th class="angka">Total</th><th></th></tr>
    @forelse($daftar as $p)
        <tr>
            <td>{{ $p->tanggal->format('d/m/Y') }}</td>
            <td>{{ $p->benih->nama }}</td>
            <td>{{ $p->pembeli ?: '-' }}</td>
            <td class="angka">{{ number_format($p->jumlah, 0, ',', '.') }}</td>
            <td class="angka">Rp {{ number_format($p->total, 0, ',', '.') }}</td>
            <td class="angka">
                <form method="POST" action="{{ route('penjualan.destroy', $p) }}" onsubmit="return confirm('Batalkan penjualan ini? Stok akan dikembalikan.')">
                    @csrf @method('DELETE')
                    <button class="btn kecil bahaya">Batalkan</button>
                </form>
            </td>
        </tr>
    @empty
        <tr><td colspan="6">Belum ada penjualan tercatat.</td></tr>
    @endforelse
</table>
<div style="margin-top:16px">{{ $daftar->links() }}</div>
@endsection
