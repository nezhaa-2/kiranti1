@extends('layouts.app')
@section('judul', 'Catat penjualan')
@section('isi')
<h1>Catat penjualan</h1>
<form class="isian" method="POST" action="{{ route('penjualan.store') }}">
    @csrf
    <label for="benih_id">Benih</label>
    <select id="benih_id" name="benih_id">
        <option value="">Pilih benih</option>
        @foreach($benih as $b)
            <option value="{{ $b->id }}" @selected(old('benih_id') == $b->id)>{{ $b->nama }} - sisa {{ $b->stok }} kg - Rp {{ number_format($b->harga_jual, 0, ',', '.') }}/kg</option>
        @endforeach
    </select>
    @error('benih_id') <div class="galat">{{ $message }}</div> @enderror

    <label for="jumlah">Jumlah (kg)</label>
    <input id="jumlah" type="number" name="jumlah" min="1" value="{{ old('jumlah') }}">
    @error('jumlah') <div class="galat">{{ $message }}</div> @enderror

    <label for="tanggal">Tanggal</label>
    <input id="tanggal" type="date" name="tanggal" value="{{ old('tanggal', now()->toDateString()) }}">
    @error('tanggal') <div class="galat">{{ $message }}</div> @enderror

    <label for="pembeli">Pembeli (opsional)</label>
    <input id="pembeli" type="text" name="pembeli" value="{{ old('pembeli') }}">

    <div class="aksi" style="margin-top:20px">
        <button class="btn">Simpan penjualan</button>
        <a class="btn sekunder" href="{{ route('penjualan.index') }}">Batal</a>
    </div>
</form>
@endsection
