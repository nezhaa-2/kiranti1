@extends('layouts.app')
@section('judul', 'Masuk')
@section('isi')
<div style="max-width:420px;margin:40px auto 0">
    <h1>Masuk</h1>
    <form class="isian" method="POST" action="{{ route('login') }}">
        @csrf
        <label for="email">Email</label>
        <input id="email" type="email" name="email" value="{{ old('email') }}" autofocus autocomplete="username">
        @error('email') <div class="galat">{{ $message }}</div> @enderror

        <label for="password">Kata sandi</label>
        <input id="password" type="password" name="password" autocomplete="current-password">
        @error('password') <div class="galat">{{ $message }}</div> @enderror

        <label style="font-weight:400"><input type="checkbox" name="ingat" value="1" style="width:auto;margin-right:6px">Ingat saya</label>

        <div class="aksi" style="margin-top:20px"><button class="btn">Masuk</button></div>
    </form>
</div>
@endsection
