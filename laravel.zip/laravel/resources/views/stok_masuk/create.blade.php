@extends('layouts.app')
@section('judul', 'Stok masuk')
@section('isi')
<h1>Catat stok masuk</h1>
<form class="isian" method="POST" action="{{ route('stok-masuk.store') }}">
    @csrf
    <label for="benih_id">Benih</label>
    <select id="benih_id" name="benih_id">
        <option value="">Pilih benih</option>
        @foreach($benih as $b)
            <option value="{{ $b->id }}" @selected(old('benih_id', $dipilih) == $b->id)>{{ $b->nama }} (stok {{ $b->stok }} kg)</option>
        @endforeach
    </select>
    @error('benih_id') <div class="galat">{{ $message }}</div> @enderror

    <label for="jumlah">Jumlah masuk (kg)</label>
    <input id="jumlah" type="number" name="jumlah" min="1" value="{{ old('jumlah') }}">
    @error('jumlah') <div class="galat">{{ $message }}</div> @enderror

    <label for="harga_beli">Harga beli per kg (Rp, opsional)</label>
    <input id="harga_beli" type="number" name="harga_beli" min="0" step="any" value="{{ old('harga_beli') }}">

    <label for="tanggal">Tanggal</label>
    <input id="tanggal" type="date" name="tanggal" value="{{ old('tanggal', now()->toDateString()) }}">

    <label for="keterangan">Keterangan (opsional)</label>
    <input id="keterangan" type="text" name="keterangan" value="{{ old('keterangan') }}">

    <div class="aksi" style="margin-top:20px"><button class="btn">Simpan stok masuk</button></div>
</form>

@if($riwayat->isNotEmpty())
    <h2>Stok masuk terakhir</h2>
    <table>
        <tr><th>Tanggal</th><th>Benih</th><th class="angka">Jumlah (kg)</th><th>Keterangan</th></tr>
        @foreach($riwayat as $r)
            <tr>
                <td>{{ $r->tanggal->format('d/m/Y') }}</td>
                <td>{{ $r->benih->nama }}</td>
                <td class="angka">{{ number_format($r->jumlah, 0, ',', '.') }}</td>
                <td>{{ $r->keterangan ?: '-' }}</td>
            </tr>
        @endforeach
    </table>
@endif
@endsection
