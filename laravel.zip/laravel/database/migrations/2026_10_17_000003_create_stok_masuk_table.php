<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('stok_masuk', function (Blueprint $t) {
            $t->id();
            $t->foreignId('benih_id')->constrained('benih')->cascadeOnDelete();
            $t->unsignedInteger('jumlah');
            $t->decimal('harga_beli', 12, 2)->nullable();
            $t->date('tanggal');
            $t->string('keterangan')->nullable();
            $t->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('stok_masuk');
    }
};
