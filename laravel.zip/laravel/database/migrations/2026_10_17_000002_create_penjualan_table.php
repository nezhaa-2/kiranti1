<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('penjualan', function (Blueprint $t) {
            $t->id();
            $t->foreignId('benih_id')->constrained('benih')->cascadeOnDelete();
            $t->unsignedInteger('jumlah');
            $t->decimal('harga_satuan', 12, 2);
            $t->decimal('total', 14, 2);
            $t->date('tanggal');
            $t->string('pembeli')->nullable();
            $t->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('penjualan');
    }
};
