<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('benih', function (Blueprint $t) {
            $t->id();
            $t->string('nama');
            $t->string('varietas')->nullable();
            $t->decimal('harga_jual', 12, 2);          // harga per kg
            $t->unsignedInteger('stok')->default(0);   // dalam kg
            $t->unsignedInteger('stok_minimum')->default(20);
            $t->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('benih');
    }
};
