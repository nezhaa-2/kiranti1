<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class AdminSeeder extends Seeder
{
    public function run(): void
    {
        // Ganti email dan kata sandi ini sebelum dipakai sungguhan
        User::updateOrCreate(
            ['email' => 'kiranti123@gmail.com'],
            ['name' => 'kiranti', 'password' => Hash::make('kiranti123')]
        );
    }
}
