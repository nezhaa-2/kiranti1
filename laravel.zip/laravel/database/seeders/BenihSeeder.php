<?php

namespace Database\Seeders;

use App\Models\Benih;
use App\Models\Penjualan;
use Illuminate\Database\Seeder;

class BenihSeeder extends Seeder
{
    public function run(): void
    {
        $contoh = [
            ['Inpari 32', 'Inpari', 16000, 300, 50],
            ['Ciherang', 'Ciherang', 14000, 250, 50],
            ['Mekongga', 'Mekongga', 15000, 120, 40],
            ['IR 64', 'IR', 13500, 40, 40],
        ];

        foreach ($contoh as [$nama, $varietas, $harga, $stok, $min]) {
            $b = Benih::create([
                'nama' => $nama, 'varietas' => $varietas,
                'harga_jual' => $harga, 'stok' => $stok, 'stok_minimum' => $min,
            ]);

            // Riwayat penjualan contoh 6 bulan terakhir
            for ($i = 5; $i >= 0; $i--) {
                $jumlah = rand(10, 60);
                Penjualan::create([
                    'benih_id' => $b->id, 'jumlah' => $jumlah,
                    'harga_satuan' => $harga, 'total' => $jumlah * $harga,
                    'tanggal' => now()->subMonths($i)->startOfMonth()->addDays(rand(0, 20)),
                    'pembeli' => 'Contoh',
                ]);
            }
        }
    }
}
