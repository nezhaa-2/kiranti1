<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\BenihController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\PenjualanController;
use App\Http\Controllers\StokMasukController;
use Illuminate\Support\Facades\Route;

// Halaman login (hanya untuk yang belum masuk)
Route::middleware('guest')->group(function () {
    Route::get('login', [AuthController::class, 'showLogin'])->name('login');
    Route::post('login', [AuthController::class, 'login'])->middleware('throttle:5,1');
});

// Semua halaman lain wajib login
Route::middleware('auth')->group(function () {
    Route::post('logout', [AuthController::class, 'logout'])->name('logout');

    Route::get('/', [DashboardController::class, 'index'])->name('dashboard');
    Route::resource('benih', BenihController::class)->except('show');
    Route::resource('penjualan', PenjualanController::class)->only(['index', 'create', 'store', 'destroy']);
    Route::get('stok-masuk/create', [StokMasukController::class, 'create'])->name('stok-masuk.create');
    Route::post('stok-masuk', [StokMasukController::class, 'store'])->name('stok-masuk.store');
});
